﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Apex.MVVM;

namespace $rootnamespace$
{
    /// <summary>
    /// The $ViewModelName$ ViewModel class.
    /// </summary>
	public class $ViewModelName$ : ViewModel
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="$ViewModelName$"/> class.
        /// </summary>
        public $ViewModelName$ ()
	    {
            //  TODO: Use the following snippets to help build viewmodels:
            //      apexnp - Creates a Notifying Property
            //      apexc - Creates a Command.
	    } 
	}
}
