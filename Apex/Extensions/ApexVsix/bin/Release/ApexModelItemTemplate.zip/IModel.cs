﻿using System;

namespace $rootnamespace$
{
    /// <summary>
    /// The <see cref="$safeitemrootname$"/> Model Interface class.
    /// </summary>
    public interface $safeitemrootname$
    {
        //  Add functions to the model here.
    }
}
